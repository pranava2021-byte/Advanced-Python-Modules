a=(100,200,300,400,800)
b=list(a)
b[4]=500
c=tuple(b)
print(c)

