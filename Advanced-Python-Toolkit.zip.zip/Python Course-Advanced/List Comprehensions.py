snacks=["Pizza", "Samosa", "Poha","French fries"]
newsnacks=[x for x in snacks ]


print(newsnacks)