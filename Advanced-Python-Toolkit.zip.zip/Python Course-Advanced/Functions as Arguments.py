'''def trial(a , b):
 print( a +" "+b )

trial("Bombay", "Wala")'''

'''list =["Pizza","Burger" ,"Momos"]
def loop():
    print(list*3)
loop()'''


list=["Pizza,Burger,Momos"]
def loop(x):

  print(x*3)
def map_simple(a,list):
      for items in list:
            a(items) 
map_simple(loop,list)


