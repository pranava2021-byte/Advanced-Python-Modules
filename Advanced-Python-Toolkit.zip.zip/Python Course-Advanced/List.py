list=["Pranava","Saksham","Rohit","True"]
print(len(list))
print(type(list))
print(max(list))
print(min(list))

print(list[-4:4])
list[1:3]="Aryan","Matru"
print(list)
list.insert(1,"Saksham")
print(list)
list.append("Samosa Party")
print(list)


