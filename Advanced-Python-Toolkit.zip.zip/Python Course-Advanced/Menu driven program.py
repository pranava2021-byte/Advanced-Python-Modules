L=[]
n=int(input("How many no. of elements do you want to enter in the list?"))
print("Enter elemnets:")
for i in range(n):
       ele=int(input("Enter the elements of the list"))
       L.append(ele)
print("The entered list is",L, '\n')
while True:
       print("Then menu driven program has following operations and you can choose from them:")
       print("1.Append an element")
       print("2.Insert an element")
       print("3.Append a list to a given list")
       print("4.Modify an  existing element")
       print("5.Delete an existing element from the given position")
       print("6.Delete an  existing element with given value")
       print("7.Exit\n")
       choice=int(input("Enter your choice(1-7):  "))
       if choice==1:
              element=int(input("Enter the element to be appended in the list"))
              print("Original List",L,'\n')
              L.append(element)
              print("New list after appending an element",L,'\n')
       elif choice==2:
              print("Original List",L,'\n')
              element=int(input("Enter the element to be inserted"))
              pos=int(input("Enter the position at which element is to be inserted"))
              L.insert(pos,element)
              print("New list after inserting an element",L,'\n')
       elif choice==3:
              print("Original List",L,'\n')
              L1=list(input("Enter another list to be appended in the list"))
              L.extend(L1)
              print("New list after appending another list",L,'\n')
       elif choice==4:
              print("Original List",L,'\n')
              pos=int(input("Enter the position to be modified"))
              new_element=int(input("Enter the new element"))
              L[pos]=new_element
              print("New list",L,'\n')
       elif choice==5:
              print("Original List",L,'\n')
              pos=int(input("Enter the position at whic element is to be deleted"))
              L.pop(pos)
              print("New list",L,'\n')
       elif choice==6:
               print("Original List",L,'\n')
               element=int(input("Enter the element to be deleted"))
               L.remove(element)
               print("New list",L,'\n')
       elif choice==7:
              break
       else:
              print("Invalid choice")
               









              



