# Classes and objects
class Microsoft:
    def __init__(silly,name,salary):
        silly.name=name
        silly.salary=salary
    def methods(silly):
     print("Hi, My name is"+ " " +silly.name)


a=Microsoft("Pranava",20000)
a.name="Rohit"
a.salary=30000
a.methods()
print(a.salary)
