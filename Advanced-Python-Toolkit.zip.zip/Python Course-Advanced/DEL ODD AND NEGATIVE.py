list1=[11,14,-299,-87,879]
length=len(list1)
i=0
while i< length:
        if list1[i] < 0:
                del list1[i]
                length=length-1
                i=i-1
        elif list1[i] % 2 !=0:
                del list1[i]
                length=length-1
                i=i-1
        i+=1
print("List after removing elements are:", list1)

            
     
